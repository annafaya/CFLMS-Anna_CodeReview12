
<!DOCTYPE html>
<html lang="en">
 <head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <meta name="description" content="<?php bloginfo('description'); ?>">
   <title><?php bloginfo('name'); ?></title>
   
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">
    
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet"> 

   <script src="js/bootstrap.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <?php wp_head(); ?>

  </head>
 <body>

  <nav class="navbar navbar-expand-md navbar-light bg-light " role="navigation">
    <div class="container-fluid">

      <h2> <?php
        wp_nav_menu( array(
            'theme_location'    => 'primary',
            'depth'             => 2, 
            // dropdown menü 'depth'
            'container'         => 'div',
            'container_class'   => 'collapse navbar-collapse',
            'container_id'      => 'bs-example-navbar-collapse-1',
            'menu_class'        => 'nav navbar-nav',
            'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
            'walker'            => new WP_Bootstrap_Navwalker(),
        ) );
        ?> </h2>
    </div>
  </nav>

  <div class="container">
    <div class="blog-header text-center">
      <h1 class="blog-title"><?php bloginfo('name'); ?></h1>
      <p class="lead blog-description"><?php bloginfo('description'); ?></p>
    </div>
  </div>
