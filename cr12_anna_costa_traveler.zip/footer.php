<footer class="blog-footer ">
     <p>&copy; <?php echo Date('Y'); ?> <?php bloginfo('name'); ?></p>
     <p>
       <a href="#">Back to top</a>
     </p>
   </footer>
   <?php wp_footer(); ?>


 </body>
</html>